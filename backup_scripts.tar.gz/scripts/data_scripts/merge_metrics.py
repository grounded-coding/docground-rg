import csv
import json

basep = "runs/t5-large-rg-review-0712192403/"

# Read the metric scores from the CSV file
metric_scores = []
with open(f'{basep}eval_metrics.csv', 'r') as file:
    csv_reader = csv.reader(file)
    for row in csv_reader:
        try:
            metric_scores.append(float(row[0]))
        except ValueError:
            print ("Skipped string line")

# Read the dataset from the JSON file
with open('data/val/labels.json', 'r') as file:
    dataset = json.load(file)

# Map the metric scores to the dataset based on the target
mapped_entries = []
dataset_index = 0
for score in metric_scores:
    while dataset_index < len(dataset) and not dataset[dataset_index]['target']:
        dataset_index += 1
    if dataset_index < len(dataset):
        mapped_entries.append([score, dataset_index])
        dataset_index += 1

# Sort the mapped entries by score in ascending order
sorted_entries = sorted(mapped_entries, key=lambda x: x[0])

# Write the sorted results to a new CSV file
with open(f'{basep}eval_metrics_mapped.csv', 'w', newline='') as file:
    csv_writer = csv.writer(file)
    csv_writer.writerow(['METRIC_NAME', 'MAPPED_ID'])
    for entry in sorted_entries:
        csv_writer.writerow([entry[0], entry[1]])